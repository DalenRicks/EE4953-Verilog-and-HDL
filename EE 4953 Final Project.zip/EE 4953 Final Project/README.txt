The processor is not in full working order. The individial partrs are fully functional
but the top level module is not. The controller needs some more fine tuning to make the processor 
100% functional, but the premise works.

To my knowledge, the arithmetic functions are working. It is the memory operations that are not.